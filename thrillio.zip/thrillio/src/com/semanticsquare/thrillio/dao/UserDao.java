package com.semanticsquare.thrillio.dao;

import com.semanticsquare.thrillio.DataStore;
import com.semanticsquare.thrillio.entities.User;

import java.util.List;

public class UserDao {
    public List<User> getUsers(){
        return DataStore.getUsers();
    }

}
